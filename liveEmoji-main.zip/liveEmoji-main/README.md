# liveEmoji

<h1>Connect with me</h1>
If you have any queries regarding any of the topic I discussed in this video feel free to talk to e using below links:<br>
facebook : https://m.facebook.com/proogramminghub<br>
instagram : @programming_hut<br>
twitter : https://twitter.com/programming_hut<br>
github : https://github.com/Pawandeep-prog<br>
discord : https://discord.gg/G5Cunyg<br>
linkedin : https://www.linkedin.com/in/programminghut<br>
youtube : https://www.youtube.com/c/programminghutofficial<br>
